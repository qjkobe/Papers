metric_learn package
====================

Submodules
----------

.. toctree::

   metric_learn.base_metric
   metric_learn.itml
   metric_learn.lfda
   metric_learn.lmnn
   metric_learn.lsml
   metric_learn.mlkr
   metric_learn.mmc
   metric_learn.nca
   metric_learn.rca
   metric_learn.sdml

Module contents
---------------

.. automodule:: metric_learn
    :members:
    :undoc-members:
    :show-inheritance:
