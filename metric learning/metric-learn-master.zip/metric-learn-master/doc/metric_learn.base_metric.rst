metric_learn.base_metric module
===============================

.. automodule:: metric_learn.base_metric
    :members:
    :undoc-members:
    :show-inheritance:
